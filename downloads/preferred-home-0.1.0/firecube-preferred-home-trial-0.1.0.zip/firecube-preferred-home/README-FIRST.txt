FIRECUBE PREFERRED-HOME TRIAL 0.1.0

Extract the whole ZIP into a new folder. Python 3.13 and official ADB required.
Run Set-Firecube-Home.cmd, enter your ADB path and Stick identifier, review the
scope and type SET FIRECUBE HOME to proceed. No launcher APK upgrade required.

This copies a verified temporary tool; it does not install an app. It saves a
device-bound backup, attempts only the Firecube Home preference, then tests one
injected Home key. Amazon stays installed. No package disabling, accessibility
setting changes, root or firmware flashing. Permission observed is not proof
that Amazon will honor this preference.

Failure triggers a guarded rollback attempt, whose result is recorded explicitly.
Keep all audits, backups and homepref-last-trial.txt. Restore-Original-Home.cmd
uses the original trial audit. Read docs/preferred-home-trial.md for details.

Upload homepref-result-*.zip after reviewing its screenshot and device identifiers.
Physical remote and reboot behavior still need verification after success.
