Version 0.1.1: waits for Firecube and records launch/foreground evidence.
Wait for automatic success before testing Netflix/Home.
Extract all files. Run Test-Home-Events.cmd. Python 3.13 and official ADB required.
Review scope and type TEST HOME EVENTS. Keep the PC connected for about 90 seconds.
After automatic success, test physical Home from a streaming app. Upload the home-events-result ZIP.
No app installation, package disabling, settings writes or root. A diagnostic log marker is written.
The PC monitor stops automatically. Amazon Home normally returns afterward.
This is a compatibility trial, not a permanent standalone Home replacement.
Read docs/home-event-trial.md for exact behavior and limitations.
