Extract the entire folder, then double-click Start-Firecube.cmd. Python 3.13 is required.
In Inventory locate official platform-tools adb.exe and enter the connected device identifier.
Open Acceptance checklist and follow docs/acceptance-round.md. Return one acceptance ZIP.
The export is read-only, captures the visible TV screen and includes package/device metadata.
No APK installs automatically. The optional disposable recovery test requires explicit confirmation.
The included recovery APK is only for dev.firecube.probe; never substitute another package.
The launcher APK is downloaded separately. Full Android source: github.com/steinja03/firecube.
This helper has automated/offscreen tests; real Windows execution for this version is pending.
