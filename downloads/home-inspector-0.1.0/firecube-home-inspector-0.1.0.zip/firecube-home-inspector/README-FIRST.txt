READ-ONLY HOME INSPECTION — NO APP INSTALL OR SETTING CHANGES.
The previous bridge trial restored your accessibility settings and paused the bridge.
Do not repeat that trial. This inspector only queries a distinct Home API lead.
Requires Python 3.13 and your working official ADB connection. No other packages.
Extract the whole folder, then double-click Run-Home-Inspector.cmd.
Enter the adb.exe path and current Stick identifier; Enter uses the prior defaults.
It copies a verified code container to /data/local/tmp, verifies a read-back copy,
and runs only package-manager queries at shell UID 2000. The APK is NOT installed.
It does not press Home, enable accessibility, set a preferred app, disable apps,
obtain root or flash firmware. The temporary inspector file remains on the Stick.
Upload the resulting home-inspection ZIP after reviewing device/package metadata.
Exposed methods/granted permissions are leads, not proof any write will succeed.
Read docs/home-inspection.md for source references and technical scope.
