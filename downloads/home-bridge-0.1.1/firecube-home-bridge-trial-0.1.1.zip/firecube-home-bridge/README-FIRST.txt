HOME BRIDGE HELPER 0.1.1 — fixes legacy ADB progress incorrectly treated as failure.
The Android APK is unchanged (0.1.0). No Firecube launcher update is required.
Extract to a new folder and keep previous receipts. Read docs/home-bridge-trial.md.
Requires Python 3.13 and your working official ADB connection; no extra Python packages.
Double-click Run-Home-Bridge.cmd. Select adb.exe and the Stick identifier.
Review the preview, then type ENABLE BRIDGE only if approving the trial.
It installs our paused helper, preserves accessibility settings, adds only its
service, tests Home once, and attempts scoped rollback on failure.
It does not disable/remove Amazon home, Alexa, or streaming apps or modify firmware.
Keep the receipt and bridge-last-receipt.txt. Restore-Home-Bridge.cmd uses them.
A rollback may fail; inspect actual outcomes. Review the bridge-result ZIP for
identifiers, metadata and visible content, then upload it for diagnosis.
The install-progress error in helper 0.1.0 occurred before accessibility writes.
This fix does not establish that Home redirection works on your Stick.
