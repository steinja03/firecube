EXPERIMENTAL REVERSIBLE HOME REDIRECT. NOT ROOT OR AMAZON REMOVAL.
Requires Python 3.13 and your already-working official ADB connection.
Read docs/home-bridge-trial.md before running anything.
Double-click Run-Home-Bridge.cmd. Locate adb.exe and enter the Stick identifier.
After reviewing the preview, type ENABLE BRIDGE only if approving this trial.
It installs only our bridge app, preserves existing accessibility settings,
adds its service, tests Home and attempts rollback on failure.
It does not disable/remove Amazon home, Alexa or streaming apps. APK installation
may register the app for other profiles, but settings/control target only user 0.
Do not discard the receipt or bridge-last-receipt.txt. Restore-Home-Bridge.cmd
uses the original receipt for a checked restoration of the saved settings.
Rollback can fail and is reported as unverified; inspect the actual outcome.
The bridge-result ZIP contains the receipt, metadata and a screenshot.
Review device identifiers, service metadata and visible content before uploading.
No exploit/firmware payload is included. Physical compatibility is unverified.
Full root/unlock assessment and source links: docs/definitive-options.md.
