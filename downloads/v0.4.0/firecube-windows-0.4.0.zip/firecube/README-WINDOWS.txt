Extract this entire folder, then double-click Start-Firecube.cmd. Python 3.13 is required.
Use Locate ADB to select official platform-tools adb.exe, then enter the device identifier.
Inventory and diagnostic collection are read-only. The disposable-app test is opt-in.
The included recovery-test APK is NOT installed automatically. See docs/next-steps.md.
The launcher APK is downloaded separately. Full Android source is at github.com/steinja03/firecube.
This Windows helper version has automated/offscreen tests; real Windows execution is pending.
