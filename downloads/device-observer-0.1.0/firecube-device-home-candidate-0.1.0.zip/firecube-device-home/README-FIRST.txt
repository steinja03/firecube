FIRECUBE DEVICE HOME CANDIDATE 0.1.0

Extract all files. Python 3.13 and official ADB are required. Existing Firecube launcher stays installed.

1. Run Start-Device-Observer.cmd and review/confirm START DEVICE OBSERVER.
2. After its Home test passes, disconnect the PC and test streaming apps plus remote Home.
3. Reconnect and run Observer-Status.cmd for a report.
4. Optional reboot recovery: run Install-Boot-Helper.cmd. On TV choose Pair / Start;
   review/approve the local ADB key if prompted. After pairing succeeds, explicitly
   enable Start Home observer after reboot. It defaults off.
5. Disconnect PC, test normal reboot and streaming/Home, then reconnect for Status.

Upload the observer-result ZIPs together with disconnected-PC/reboot/playback results.
The new device observer, local pairing and reboot startup remain unverified until
these device tests pass. Existing PC trial proved two redirects only.

The optional app key grants ADB shell access. Its network use is restricted to
127.0.0.1:5555; private key stays in private app storage. No root or firmware writes.
Amazon/Alexa are not removed and no package/default/accessibility states are disabled.

STOP: on TV turn boot start off and choose Stop in Firecube Home Controller.
PC Stop-Device-Observer.cmd ends the current session but cannot change that TV toggle.
If needed, force-stop/uninstall the controller in Fire OS settings before rebooting.
The normal Amazon launcher remains available.

Read docs/device-observer.md for exact scope, recovery and acceptance requirements.
AdbLib-derived framing/RSA code: third-party/AdbLib-LICENSE.txt.
